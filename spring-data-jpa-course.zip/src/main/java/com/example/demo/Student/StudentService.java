package com.example.demo.Student;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import javax.naming.InsufficientResourcesException;
import javax.transaction.Transactional;
import java.time.LocalDate;
import java.time.Month;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service //Service组件
public class StudentService {
    private final StudentRepository studentRepository;
    @Autowired //依赖注入StudentRepository
    public StudentService(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    @GetMapping
    public List<Student> getStudents(){
        return studentRepository.findAll();
    }

    public void addNewStudent(Student student) {
       Optional<Student> studentOptional=
        studentRepository.findStudentByEmail(student.getEmail());
       //如果状态变量无法获取到学生邮件则报email token错误邮件丢失错误
       if (studentOptional.isPresent()){
           throw  new IllegalStateException("email tocken");
       }
       //将数据保存在数据库中
        studentRepository.save(student);
    }


    public void deleteStudent(Long studentId) {
           boolean exists=  studentRepository.existsById(studentId);
           //如果不存在学生id不存在则状态异常IllegalStateException
           if (!exists){
               throw  new IllegalStateException("with the student"+studentId+"does not exist");
           }
           //如果存在学生id
           //删除学生信息在数据库中
           studentRepository.deleteById(studentId);


    }
     //修改学生信息
    @Transactional
    public void UpdateStudent(Long studentId, String name, String email) {
     Student student= studentRepository.findById(studentId)
             .orElseThrow(()->new IllegalStateException("with the student"+studentId+"does not exist"));
     //或者找不不学生id故状态异常·

     //如果数据库学生2姓名不为空且长度大于0且不等于修改的学生姓名
     if(name!=null&&
     name.length()>0&&!Objects.equals(student.getName(),name)){
         //开始修改学生姓名
            student.setName(name);
            //如果学生的邮件信息不为空且长度大于0且不等于修改的学生邮件信息该修改学生信息
            if(email!=null&&email.length()>0&&!Objects.equals(student.getEmail(),email)){
                Optional<Student> studentOptional=studentRepository.findStudentByEmail(email);
                if (studentOptional.isPresent()){
                    throw new IllegalStateException("email token");
                }
                //设置学生邮件信息
                student.setEmail(email);
            }

        }
    }
}
