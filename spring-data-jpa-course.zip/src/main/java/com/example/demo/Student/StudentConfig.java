package com.example.demo.Student;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDate;
import java.time.Month;
import java.util.List;

@Configuration //Configuration组件
public class StudentConfig {
    @Bean //生命周倜
    public CommandLineRunner commandLineRunner(StudentRepository repository){
        return args -> {
            Student marry=   new Student(
                            "魏嘉福1",
                            "18919002649@189.cn",
                            LocalDate.of(1998, Month.OCTOBER,1)
            );
            Student jack=   new Student(
                    "魏嘉福23",
                    "18919002649@189.cn",
                    LocalDate.of(1998, Month.OCTOBER,1)
            );
            //将学生信息上传到数据库中
            repository.saveAll(
                    List.of(marry,jack)
            );

        };


    }
}
