package com.example.demo.Student;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.transaction.Transactional;
import java.time.LocalDate;
import java.time.Month;
import java.util.List;
@RestController //告诉String将渲染结果返回给字符串String,然后将返回结果给调用者
@RequestMapping("/api/v1/student") //用来请求处理地址映射的注释
public class StudentController {
    private final StudentService studentService;
    @Autowired //依赖注入StudentService
    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    @GetMapping
    public List<Student> getStudents(){
        return studentService.getStudents();

    }
    //增加学生信息
    @PostMapping
    public void registerNewStudent( @RequestBody  Student student){
        studentService.addNewStudent(student);
    }
    //删除学生个人信息通过查找学生个人id
    @DeleteMapping(path = "{studentId}")
    public void deleteStudent(@PathVariable("studentId") Long studentId){
            studentService.deleteStudent(studentId);

    }


 //修改学生信息
    @PutMapping(path = "{studentId}")
    public void UpdateStudent(@PathVariable("studentId") Long studentId,
                              @RequestParam(required = false) String name,
                              @RequestParam(required = false) String email){
        studentService.UpdateStudent(studentId,name,email);
    }


}

